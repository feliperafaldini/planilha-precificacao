# Planilha de Precificação para Marketplaces

Obrigado pela compra. Este pacote contém a planilha e as instruções de uso.

## Arquivo

`Planilha_Precificacao_Marketplaces.xlsx`

## Como abrir

- Excel 2016 ou superior; ou
- LibreOffice Calc; ou
- Google Sheets (importe o .xlsx; pequenas diferenças de formatação podem aparecer).

## Como usar

1. Abra a aba **Premissas** e ajuste:
   - imposto sobre a venda;
   - margem desejada;
   - custo fixo mensal rateado;
   - comissão e taxa fixa de cada canal.
2. Abra a aba **Calculadora** e troque, nas células amarelas:
   - produto;
   - custo unitário;
   - frete/embalagem;
   - preço de venda.
3. Veja o lucro, a margem, o markup, o ROAS de equilíbrio e o preço mínimo.
4. Use a aba **Comparativo** para ver qual canal paga melhor em cada produto.
5. Confira a aba **Taxas** antes de precificar: as plataformas mudam as regras.
6. O **Dashboard** mostra o lucro total por canal.

## O que cada aba faz

- **Instruções:** o que é, como usar e o que significam margem, markup, ROAS e preço mínimo.
- **Premissas:** imposto, margem desejada, custo fixo e taxas de cada canal.
- **Calculadora:** uma linha por produto e canal, com lucro, margem, markup, ROAS e preço mínimo.
- **Comparativo:** lucro e margem de ML, Shopee e Amazon lado a lado.
- **Taxas:** referências de novembro/2026, com fonte e data.
- **Dashboard:** contagem de status e gráfico de lucro por canal.

## Avisos importantes

- As taxas de marketplace mudam com frequência e variam por categoria, peso, prazo e tipo de anúncio. A planilha usa referências de novembro/2026 e permite ajustar todos os valores.
- O imposto é configurável. MEI, Simples Nacional e pessoa física têm regras diferentes. Consulte seu contador.
- O preço mínimo do Mercado Livre considera as faixas de custo fixo: 50% do valor abaixo de R$ 12,50, taxa fixa entre R$ 12,50 e R$ 79 e zero acima de R$ 79.
- Na Shopee, o preço mínimo usa a taxa fixa da faixa do preço de venda atual. Se ele cair em outra faixa, ajuste a taxa fixa na coluna F e veja o novo valor.
- A planilha calcula; ela não garante venda nem lucro. O resultado depende do seu preço, custo, volume e canal.

## Licença

Uso pessoal ou na sua empresa. Proibida a revenda, a redistribuição e a publicação do arquivo.

## Suporte

Dúvida na importação ou no uso: responda o e-mail da compra com a aba e a célula onde está o problema.
